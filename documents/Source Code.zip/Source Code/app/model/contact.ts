export interface Contact {
  userName: string;
  userContactNo: string;
  email: string;
  comment: string;
}
